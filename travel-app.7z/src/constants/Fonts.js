export default {
    REGULAR: "Regular",
    BOLD: "Bold",
    PRIMARY: "Helvetica"
  };
  