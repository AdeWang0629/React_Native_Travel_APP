export default {
    BASIC_BACKGROUND: "#D5F2F2",
    ACTIVE: "#FF9501",
    PINK: "#F6565A",
    WHITE: "#FFFFFF",
    YELLOW: "#F99C1A",
    BROWN: "#E66000",
    BLACK: "#333333",
  };
  